<?php /* D:\XAMPP\htdocs\pos\resources\views/dashboard/message/inbox.blade.php */ ?>
<?php $__env->startSection('title','All Message'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.inc.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><div class="content-body">
    <div class="card">
        <div class="card-header">
            <h5 class="title">
            <h5 class="card-title">Messages <a
                        href="#sendUserPM" data-toggle="modal"
                        data-remote="false" data-type="reminder"
                        class="btn btn-large btn-success"
                        title="Partial Payment"
                ><span class="icon-mail"></span> Compose </a></h5>

            </h5>
            <hr>
            <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
            <div class="heading-elements">
                <ul class="list-inline mb-0">
                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="card-content">
            <div id="notify" class="alert alert-success" style="display:none;">
                <a href="#" class="close" data-dismiss="alert">&times;</a>

                <div class="message"></div>
            </div>
            <div class="card-body">


                <table id="notestable" class="table table-striped table-bordered zero-configuration" cellspacing="0"
                       width="100%">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>message</th>
                        <th>Subject</th>
                        <th>Sender Name</th>
                        <th>Sender Email</th>
                        <th>Date</th>
                        <th> Action</th>


                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e(str_limit(strip_tags($message->message,20))); ?>..</td>
                            <td><?php echo e($message->subject); ?></td>
                            <td><?php echo e($message->RelationMessageSender->email); ?></td>
                            <td><?php echo e($message->RelationMessageSender->name); ?></td>
                            <td><?php echo e($message->created_at); ?></td>
                            <td>
                                
                            <a href="<?php echo e(Route('view_message',$message->id)); ?>" class="btn btn-success btn-sm"><i class="fa fa-eye"></i> </a>
                         <a class="btn btn-danger btn-sm delete-object" href="#" data-object-id="1"> <i class="fa fa-trash"></i> </a>
                         <div id="delete_model" class="modal fade">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">

                                    <h4 class="modal-title">Delete Product</h4>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                                                aria-hidden="true">&times;</span></button>
                                </div>
                                <div class="modal-body">
                                    <p>Are you sure you want to delete this product?</p>
                                </div>
                                <div class="modal-footer">
                                    <form method="POST" action="<?php echo e(Route('delete_message',$message->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                    <button type="submit"  class="btn btn-danger "><i class='fa fa-trash'></i>Delete</button>
                                    <button type="button" data-dismiss="modal" class="btn">Cancel</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                </table>

            </div>
        </div>
    </div>
</div>

</div>
</div>
<div id="sendUserPM" class="modal fade">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">

                    <h4 class="modal-title">Send Message</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <form method="post" action="<?php echo e(Route('send_message_form')); ?>">
                <?php echo csrf_field(); ?>
                <div class="modal-body" id="emailbody">
                    
                        <div class="row">
                        <input type="hidden" value="<?php echo e(Auth::user()->id); ?>" name="sender">
                                <div class="form-group">
                                        <label for="to" class="control-label">To:</label>
                                        <select style="padding-left:20px;" class="custom-select" name="to">
                                        <option value="">Select Reciever Email</option>
                                        <?php $__currentLoopData = $emails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $email): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(Auth::user()->id == $email->id): ?>
                                                <?php else: ?>
                                                <option  value="<?php echo e($email->id); ?>"><?php echo e($email->email); ?></option>
                                            <?php endif; ?>    
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    </div>
                                    <?php if($errors->has('to')): ?>
                                    <div class="alert alert-danger">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <p><?php echo e($errors->first('to')); ?></p>
                                    </div>
                                    <?php endif; ?>

                        </div>
                        <div class="row">
                            <div class="col mb-1"><label
                                        for="shortnote">Subject</label>
                                <input type="text" class="form-control"
                                       name="subject" id="subject">
                            </div>
                            <?php if($errors->has('subject')): ?>
                                    <div class="alert alert-danger">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <p><?php echo e($errors->first('to')); ?></p>
                                    </div>
                                    <?php endif; ?>
                        </div>
                        <div class="row">
                            <div class="col mb-1"><label
                                        for="shortnote">Message</label>
                                <textarea name="message" class="summernote" id="contents" title="Contents"></textarea>
                            </div>
                            <?php if($errors->has('message')): ?>
                                    <div class="alert alert-danger">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <p><?php echo e($errors->first('to')); ?></p>
                                    </div>
                                    <?php endif; ?>
                        </div>
                    
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default"
                            data-dismiss="modal"> Close</button>
                    <button type="submit" class="btn btn-primary" >Send</button>
                </div>
                </form>
            </div>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>