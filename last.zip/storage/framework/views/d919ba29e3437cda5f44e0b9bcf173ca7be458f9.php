<?php /* D:\XAMPP\htdocs\pos\resources\views/dashboard/balancesummary.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<!-- Horizontal navigation-->
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
        <div class="content-body"><div class="content-body">
    <div class="card">
        <div class="card-header">
            <h5>BalanceSheet</h5>
            <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
            <div class="heading-elements">
                <ul class="list-inline mb-0">
                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="card-content">
            <div id="notify" class="alert alert-success" style="display:none;">
                <a href="#" class="close" data-dismiss="alert">&times;</a>

                <div class="message"></div>
            </div>
            <div class="card-body">

                <h5 class="title bg-gradient-x-info p-1 white">
                    BasicAccounts                </h5>
                <p>&nbsp;</p>
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Account</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                    <td>1</td>                    
                    <td>Sales Account</td>
                    <td>123456</td>
                   
                    <td>$ 181,764.76</td>
                    </tr>                    </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>

                        <th></th>

                        <th><h3 class="text-xl-left">$ 181,764.76</h3></th>
                    </tr>
                    </tfoot>
                </table>
                <h5 class="title bg-gradient-x-purple p-1 white">
                    AssetsAccounts                </h5>
                <p>&nbsp;</p>
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Account</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
                                        </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>

                        <th></th>

                        <th><h3 class="text-xl-left">$ 0.00</h3></th>
                    </tr>
                    </tfoot>
                </table>

                <h5 class="title bg-gradient-x-danger p-1 white">
                    ExpensesAccounts                </h5>
                <p>&nbsp;</p>
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Account</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
                                        </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>

                        <th></th>

                        <th><h3 class="text-xl-left">$ 0.00</h3></th>
                    </tr>
                    </tfoot>
                </table>

                <h5 class="title bg-gradient-x-success p-1 white">
                    IncomeAccounts                </h5>
                <p>&nbsp;</p>
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Account</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
                                        </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>

                        <th></th>

                        <th><h3 class="text-xl-left">$ 0.00</h3></th>
                    </tr>
                    </tfoot>
                </table>

                <h5 class="title bg-gradient-x-warning p-1 white">
                    LiabilitiesAccounts                </h5>
                <p>&nbsp;</p>
                <table class="table">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Account</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
                                        </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>

                        <th></th>

                        <th><h3 class="text-xl-left">$ 0.00</h3></th>
                    </tr>
                    </tfoot>
                </table>

                <h5 class="title bg-gradient-x-grey-blue p-1 white">
                    EquityAccounts                </h5>
                <p>&nbsp;</p>
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Account</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>
                                        </tbody>
                    <tfoot>
                    <tr>
                        <th></th>
                        <th></th>

                        <th></th>

                        <th><h3 class="text-xl-left">$ 0.00</h3></th>
                    </tr>
                    </tfoot>
                </table>


                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th>Type</th>
                        <th>Balance</th>
                    </tr>
                    </thead>
                    <tbody>

                    <tr>
                        <td>Basic</td>
                        <td>$ 181,764.76</td>

                    </tr>
                    <tr>
                        <td>Assets</td>
                        <td>$ 0.00</td>

                    </tr>
                    <tr>
                        <td>Expenses</td>
                        <td>$ 0.00</td>

                    </tr>
                    <tr>
                        <td>Income</td>
                        <td>$ 0.00</td>

                    </tr>
                    <tr>
                        <td>Liabilities</td>
                        <td>$ 0.00</td>

                    </tr>
                    <tr>
                        <td>Equity</td>
                        <td>$ 0.00</td>

                    </tr>
                    </tbody>
                    <tfoot>

                    </tfoot>
                </table>

            </div>
        </div>
    </div>
    <script type="text/javascript">
        $(document).ready(function () {

            //datatables
            $('.dtable').DataTable({responsive: true});

        });
    </script></div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>