<?php /* D:\XAMPP\htdocs\digitalaccountant\resources\views/dashboard/product/addproduct.blade.php */ ?>
<?php $__env->startSection('title','Add Product'); ?>
<?php $__env->startSection('content'); ?>
<!-- Horizontal navigation-->
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
            <?php echo $__env->make('layouts.inc.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="content-body"><div class="content-body">
    <div class="card">
        <div class="card-header">
            <h5>Create  Vendor</h5>
            <hr>
            <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
            <div class="heading-elements">
                <ul class="list-inline mb-0">
                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="card-content">
            <div id="notify" class="alert alert-success" style="display:none;">
                <a href="#" class="close" data-dismiss="alert">&times;</a>

                <div class="message"></div>
            </div>
            <div class="card-body">
                <form method="post" action="<?php echo e(Route('product_add_form')); ?>"  enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label"
                               for="product_code">Company Name</label>

                        <div class="col-sm-4">
                            <input type="text" placeholder="Company Name"
                                   class="form-control" name="product_name">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label"
                               for="product_code">Attention</label>

                        <div class="col-sm-4">
                            <input type="text" placeholder="First Name"
                                   class="form-control" name="product_name">
                                   <br>
                            <input type="text" placeholder="Last Name"
                                   class="form-control" name="product_name">
                        </div>
                    </div>
                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label">Email</label>

                        <div class="col-sm-4">
                            <div class="input-group">
                            <input type="text" placeholder="Email"
                                   class="form-control" name="product_name">
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="form-group row">

                    <label class="col-sm-2 col-form-label"
                               for="product_cat">Address</label>
                        <div class="col-sm-4">
                            <div class="input-group">

                                <input type="text" name="price" class="form-control"
                                       placeholder="Address">
                            </div>
                        </div>
                    </div>
                    <hr>
                    <div class="form-group row">

                    <label class="col-sm-2 col-form-label"
                        for="product_cat">Bank Account Number</label>

                    <div class="col-sm-4">
                    <input type="text" name="price" class="form-control"
                                       placeholder="Bank Account Number">
                    </div>
                    </div>
                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"
                               for="product_cat">Bank Account</label>

                        <div class="col-sm-4">
                            <select name="unit" class="form-control">
                                <option value=''>Bank Asia</option>
                                <option value='Kg'>Brack Bank</option>
                                <option value='Pc'>Dutch Bangla </option>
                                <option value='Box'>Union Bank</option>
                                <option value='Unit'>Jamuna Bank</option>              
                             </select>
                        </div>
                    </div>
                    <div class="form-group row">

                        <label class="col-sm-2 col-form-label"></label>

                        <div class="col-sm-4">
                            <input type="submit" class="btn btn-lg btn-blue margin-bottom"
                                   value="Submit" data-loading-text="Adding...">
                        </div>
                    </div>
                </form>
            </div>
        </div>   
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>