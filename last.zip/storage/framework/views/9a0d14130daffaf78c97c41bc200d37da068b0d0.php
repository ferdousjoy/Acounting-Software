<?php /* D:\XAMPP\htdocs\pos\resources\views/layouts/dashboard.blade.php */ ?>
<?php echo $__env->make('layouts.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="c_body"></div>
            <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
<?php echo $__env->make('layouts.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>