<?php /* /home/sasapplication/account.sasapplication.com/resources/views/dashboard/po/edit.blade.php */ ?>

<?php $__env->startSection('title','PO Setup'); ?>
<?php $__env->startSection('content'); ?>
<style>
        .inputholder{
           margin-right: 20px;
            width: 14%;
            text-align: center;
        }
        .addbtn{
            margin-top: 30px;
        }
        .inputholder label{
             text-transform: capitalize;
            font-size: 18px;
        }
        .form-container{
          padding:10px;
          padding-bottom:25px;
          margin:0 auto;
          margin-top:20px;
          width:100%;
          border-radius:20px;
          background-color: #ececec;
        }

        .add-one{
          color:green;
          text-align:center;
          font-weight:bolder;
          cursor:pointer;
          margin-top:10px;
        }

        .delete {
            color: white;
            background-color: rgb(231, 76, 60);
            text-align: center;
            font-weight: 700;
            border-radius: 50%;
            width: 20px;
            height:20px;
            cursor: pointer;
            border: 0;
            padding: 0;
            position: absolute;
            right:36px;
            top:calc(50% - 10px);
        }
        #invoicesTable th,
        #invoicesTable td{vertical-align: middle;}
        #singlebutton{
          width:100%;
          margin-top:20px;
        }

        .title{
          text-align:center;
          font-size:40px;
          margin-bottom:40px;
        }

        .dynamic-element{
          margin-bottom:0px;
        }
        .ivAmmountBox{position: relative;}
        .ivAmmount{
          background: transparent;
            border: 0;
            text-align: center;
        }
    </style>
<!-- Horizontal navigation-->
<?php echo $__env->make('layouts.inc.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="app-content content">
  <div class="content-wrapper">
    <div class="content-header row">
    </div>

    <div class="content-body">
      <div class="card">
        <div class="card-content">
          <div id="notify" class="alert alert-success" style="display:none;">
              <a href="#" class="close" data-dismiss="alert">&times;</a>
              <div class="message"></div>
          </div>
          <div class="card-body">
            <form id="invoicesForm" method="post" action="<?php echo e(route('pos.update',$po->id)); ?>">
              <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
              <div class="row">
                 <div class="col-sm-12">
                   <div id="customerpanel" class="inner-cmp-pnl">
                      <div class="form-group row">
                        <div class="frmSearch col-sm-12">
                          <h2>Update PO Setup</h2>
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="row" style="transform:translateX(-29px);">
                          <div class="col-md-4">
                            <label for="po_no" style="float:right" class="caption">PO No</label>
                          </div>
                          <div class="col-md-6">
                             <input type="text" class="form-control" name="po_no" style="margin-bottom:17px;border:1px solid #babfc7;padding:10px;border-radius:4px;" value="<?php echo e($po->po_no); ?>">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
              </div>
              <hr>
              <div class="row">
                <div class="col-sm-12 cmp-pnl">
                    <div class="inner-cmp-pnl">
                      <div class="form-group row">
                        <div class="col-sm-4">
                          <div class="row">
                            <div class="col-md-4">
                              <label for="invocieno" style="float:right" class="caption">Customer</label>
                            </div>
                            <div class="col-md-6">
                              <select name="customer_id" id="customer_id" class="form-control">
                                 <option>--choose one--</option>
                                  <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($customer->id); ?>"<?php echo e(($customer->id == $po->customer_id)?' selected':''); ?>><?php echo e($customer->name); ?></option>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-4">
                          <div class="row">
                            <div class="col-md-4">
                              <label for="shipping_address" style="float:right" class="caption">Shipping</label>
                            </div>
                            <div class="col-md-6">
                              <select name="shipping_address" id="shipping_address" class="selectpicker form-control">
                                <option>--choose one--</option>
                                 <?php $__currentLoopData = $shipping_addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping_address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <option value="<?php echo e($shipping_address->line); ?>"<?php echo e(($shipping_address->line == $po->shipping_address)?' selected':''); ?>><?php echo e($shipping_address->line); ?></option>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </select>
                            </div>
                          </div>
                        </div>
                        <div class="col-sm-4">
                        <div class="row">
                          <div class="col-md-4">
                            <label for="invocieno" style="float:right" class="caption">Issue Date</label>
                          </div>
                          <div class="col-md-6">
                            <input type="date" class="form-control"  name="po_date" data-toggle="datepicker" value="<?php echo e($po->po_date); ?>" autocomplete="false">
                          </div>
                        </div>
                      </div>
                      </div>
                    </div>
                    <div class="form-group row">
                      <div class="col-sm-4">
                        <div class="row">
                          <div class="col-md-4">
                            <label for="invocieno" style="float:right" class="caption">Currency</label>
                          </div>
                          <div class="col-md-6">
                            <select name="currency" class="selectpicker form-control">
                              <option value="BDT"<?php echo e(($po->currency == "BDT")?' selected':''); ?>>BDT</option>
                              <option value="Indian"<?php echo e(($po->currency == "Indian")?' selected':''); ?>>Indian</option>
                              <option value="Doller"<?php echo e(($po->currency == "Doller")?' selected':''); ?>>Doller</option>
                            </select>
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="row">
                          <div class="col-md-4">
                            <label for="invocieno" style="float:right" class="caption">Expire Date</label>
                          </div>
                          <div class="col-md-6">
                            <input type="date" class="form-control"  name="po_exdate" data-toggle="datepicker" value="<?php echo e($po->po_exdate); ?>" autocomplete="false">
                          </div>
                        </div>
                      </div>
                      <div class="col-sm-4">
                        <div class="row">
                          <div class="col-md-4">
                            <label for="invocieno" style="float:right" class="caption">Terms & Condition</label>
                          </div>
                          <div class="col-md-6">
                            <textarea cols="25" rows="3" name="notes" style="resize:none; border-radius:2px;border-color:#e4e4e4;"><?php echo e($po->notes); ?></textarea>
                          </div>
                        </div>
                      </div>
                    </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-12">
                  <table id="invoicesTable" class="table table-striped table-bordered  dataex-res-constructor">
                    <thead>
                      <tr>
                        <th>Product</th>
                        <th>Description</th>
                        <th>Quantity</th>
                        <th>Unit</th>
                        <th>Price</th>
                        <th>Tax</th>
                        <th>Amount</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $__currentLoopData = $pos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$po_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td style="width:150px">
                          <select name="product[]" class="form-control ivProduct" style="width:150px">
                            <option disable>--Choose one--</option>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($product->id); ?>"<?php echo e(($product->id == $po_product->product_id)?' selected':''); ?>><?php echo e($product->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                        </td>
                        <td style="width:220px;"><textarea class="form-control ivDescription" name="description[]" style="height:39px;border:none;background:transparent"><?php echo e($po_product->description); ?></textarea></td>
                        <td style="width:50px!important"><input type="text" class="form-control ivQuantity" name="quantity[]"  style="width:70px !important;border:none;background:transparent;" value="<?php echo e($po_product->quantity); ?>"></td>
                        <td style="width:50px!important";><input class="form-control ivUnit" name="unit[]" style="width:60px !important;border:none;background:transparent" value="<?php echo e($po_product->unit); ?>"></td>
                        <td style="width:50px!important"><input type="text" class="form-control ivPrice"  name="price[]" style="width:70px !important;border:none;background:transparent;" value="<?php echo e($po_product->price); ?>" ></td>
                        <td style="width: 140px !important">

                          <select class="form-control ivTax"  name="tax[]"  style="width: 140px !important" value="0">
                            <option value="0" selected>No Tax</option>
                            <?php $__currentLoopData = $taxs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tax->percentage); ?>"<?php echo e(($tax->percentage == $po_product->tax)?' selected':''); ?>><?php echo e($tax->tax); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>

                        </td>
                        <td style="width:100px" class="ivAmmountBox">
                          <?php if($k>0): ?> <button type="button" class="delete">&times;</button> <?php endif; ?>
                          <input type="text" class="form-control ivAmmount" name="total[]" style="width:100px;border:none;background:transparent" value="<?php echo e($po_product->total); ?>" readonly>
                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                    <tfoot>
                      <tr>
                        <td colspan="7">
                          <button type="button" id="add_one" class="btn btn-success btn-block">+ Add More</button>
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                  <div class="dynamic-stuff"></div>
                </div>
              </div>

              <div class="row" >
                <div class="col-md-12 text-center" style="padding-bottom:20px; margin-top:15px;">
                  <input style="border-radious:30px;margin-botom:20px;"  type="submit" class="btn btn-primary sub-btn" value="Save" data-loading-text="Creating...">
                  <input style="border-radious:30px;margin-botom:20px;"  type="submit" class="btn btn-primary sub-btn" value="Send" data-loading-text="Creating...">
                  <a href="#" style="border-radious:30px;margin-botom:20px;" class="btn btn-primary sub-btn" value="Send" data-loading-text="Creating...">Print</a>
                </div>
              </div>

            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer_scripts'); ?>
<script>

$(document).ready(function(){
    $('#customer_id').change(function() {
      var customer_id = $(this).val();
        $.ajax({
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            method:'POST',
            url:'<?php echo e(route("pos.getshiplist")); ?>',
            data:{customer_id: customer_id},
            success: function (data) {
              $( "#shipping_address" ).html(data);
            }
       });
    });
});


$(function(){
  $form = $('#invoicesForm');
  $table = $form.find('#invoicesTable');
  $tbody = $table.find('tbody');

  $(function(){
    //Clone the hidden element and shows it
    $form.on('click','#add_one',function(){

      $tr = $tbody.find('tr:first-child').clone();
      //$tr.find('.ivProduct').html('');
      $tr.find('.ivDescription').html('');
      $tr.find('.ivQuantity').val(0);
      $tr.find('.ivPrice').val(0);
      $tr.find('.ivTax').prop("selectedIndex", 0);
      $tr.find('.ivAmmount').val(0);
      $tr.find('td:last-child').append('<button type="button" class="delete">&times;</button>');
      $tr.appendTo( $tbody );

    });

    $form.on('click','.delete',function(){
      $(this).parents('tr').remove();
    });
  });



  $(function(){
    $form.on('change','.ivProduct',function() {
      var product_id = $(this).val();
      var $tr = $(this).parents('tr');
      $.ajax({
          headers:{'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
          type:'POST',
          url:'<?php echo e(route("pos.getAjaxProduct")); ?>',
          data:{product_id: product_id},
          success: function (data) {
            $data = JSON.parse(data);
            $tr.find('.ivDescription').html($data.description);
            $tr.find('.ivPrice').val($data.price);
            //$tr.find('.ivTax').val($data.tax);
            $tr.find('.ivUnit').val($data.unit);

            //console.log($data);
            $tr.find('.ivTax option').each(function(){
                if($(this).val()==$data.tax){
                    $(this).attr("selected","selected");
                }else if($(this).is(":selected")){
                  $(this).removeAttr('selected');
                }
            });
          }
      });
    });


  });
  $(function(){
    $form.on('keyup','.ivQuantity,.ivPrice',function(){
        $tr = $(this).parents('tr');

        var price = parseInt($tr.find('.ivPrice').val());
        var qty = parseInt($tr.find('.ivQuantity').val());
        //var vat = parseInt($('#vat-0').val());
        $tr.find('.ivAmmount').val(price*qty);
        //$('#ivAmmount').val((price*amount) + vat);
    });
  });
  $form.on('change','.ivTax',function(){
    $tr = $(this).parents('tr');

    var price = parseInt($tr.find('.ivPrice').val());
    var qty = parseInt($tr.find('.ivQuantity').val());
    var tax = parseInt($tr.find('.ivTax').val());
    var totaltax = parseInt(price*qty*tax/100);
    $tr.find('.ivAmmount').val(price*qty + totaltax);
  });
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>