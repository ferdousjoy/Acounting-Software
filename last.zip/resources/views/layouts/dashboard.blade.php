@include('layouts.inc.header')
    <div id="c_body"></div>
            @yield('content')
            </div>
        </div>
    </div>
@include('layouts.inc.footer')