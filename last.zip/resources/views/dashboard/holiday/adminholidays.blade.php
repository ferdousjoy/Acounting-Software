@extends('layouts.dashboard')
@section('content')
<!-- Horizontal navigation-->
@extends('layouts.dashboard')
@section('content')
<!-- Horizontal navigation-->
<div class="app-content content">
    <div class="content-wrapper">
        <div class="content-header row">
        </div>
<div class="content">
    <div class="card card-block">
        <div class="card-body">
            <!-- Notification -->
            <div class="alert"></div>


            <div id='adate'></div>
        </div>
    </div>
</div>
</div>
</div>
@endsection
@endsection